# Complete the guided exercise

[← Return to the class guide](../START-HERE.md)

These prompts belong to the single 60-minute session. Use them in the displayed order.

## Prompt 10 · Adapt and review a campaign concept

**Inputs**
`AGENTS.md`, `brand/context.md`, `.agents/skills/albert-copper-cup-ad-creative/SKILL.md`, `agents/marketing_lead.md`, `agents/growth_strategist.md`, `agents/content_creator.md`, `agents/creative_designer.md`, `agents/website_designer.md`, `agents/growth_analyst.md`, `campaigns/discovery-box/run-01/strategy.md`, `campaigns/discovery-box/run-01/ad-copy.md`, `campaigns/discovery-box/coordinated-01/handoff.md`

[Copy the full prompt](../prompts/10-adapt-and-review-a-campaign-concept.txt)

```text
Read AGENTS.md, brand/context.md including Current campaign, the ad skill, all six role cards, the reviewed run-01 files, and coordinated-01/handoff.md. Complete a ten-minute exercise for people setting up their first home office. Preserve the supported product, price, shipping, and CTA. For the Copper Cup demo those are three 100 g bags, USD 29, USD 5 shipping, and Explore the Discovery Box.
Act as Marketing Team Lead in the main conversation. Save the changed audience assignment as campaigns/discovery-box/exercise-01/assignment.md while preserving the original context and earlier runs. Explicitly assign a short audience rationale to the Growth Strategist, then one revised copy concept and visual direction to the Content Creator and Creative Designer. Return the strategy, headline, body, CTA, visual direction, image prompt, and planned alt text in one concept-and-review.md file in that exercise folder. Include a before-and-after audience comparison, a source-check table, actual task references or sequential fallback labels, and one human revision decision. Keep image generation and external actions pending separate decisions.
Use explicit subagent assignments when supported. Use the named local Codex role or pass its complete Markdown instructions to an available worker. In Work, supply accessible files and explicitly delegate. Return actual task activity or references and output paths. If delegation is unavailable, label the result a sequential role-based draft. A role definition alone is not an agent execution receipt.
Keep this classroom task inside the selected project. Prepare draft files only. Hold external sends, publication, scheduling, spending, deletion, and permission changes for a separate human decision. If file tools are unavailable, return downloadable files or full copyable text and name the missing file access. Report saved files separately from proposals.
```

**Expected result**
`campaigns/discovery-box/exercise-01/assignment.md`, `campaigns/discovery-box/exercise-01/concept-and-review.md`.

**Check before continuing**
Compare audiences, trace one claim, preserve the supported offer, and choose a specific revision.
