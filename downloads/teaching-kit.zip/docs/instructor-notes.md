# Full instructor speaking script

[← Return to the course](../README.md)

Use prompts 01–10 in order within this single session. Copy only the text between each BEGIN and END marker.

## Slide 01 · Build Your AI Marketing Team with Agents

TEACHING SCRIPT
This single 60-minute class begins with an interview that creates the brand context and project instructions. We then create a skill, define six roles, and start specialist assignments. A coordinated campaign demonstrates independent handoffs and review. We will also see Dot and voice, a private campaign library, and a recurring-brief proposal before your ten-minute exercise. Copper Cup and its campaign figures are fictional teaching examples.

TEACHING TIME
Allow 1 minute within this single 60-minute session.

SOURCES
Fictional Copper Cup classroom example. Official file and agent guidance checked October 15, 2026.
https://learn.chatgpt.com/docs/agent-configuration/agents-md
https://learn.chatgpt.com/docs/build-skills
https://learn.chatgpt.com/docs/agent-configuration/subagents

## Slide 02 · Your single-session course route

TEACHING SCRIPT
We use prompts 01 through 10 in teaching order. The opening interview creates the two foundation files, which gives us more time for assignments and team coordination. All demonstrations and the guided exercise fit within this hour. The final four slides provide reference details, and this curriculum assumes one teaching session.

TEACHING TIME
Allow 1 minute within this single 60-minute session.

SOURCES
Fictional Copper Cup classroom example. Official file and agent guidance checked October 15, 2026.
https://learn.chatgpt.com/docs/agent-configuration/agents-md
https://learn.chatgpt.com/docs/build-skills
https://learn.chatgpt.com/docs/agent-configuration/subagents

## Slide 03 · Interview me and create two files

TEACHING SCRIPT
Create an empty local Codex folder or a fresh Work workspace before the demonstration. Paste the interview prompt and answer its questions. Choose the Copper Cup demo so the supplied facts stay consistent with the recordings. Use the prepared answer card to keep the interview focused. After the answers, open brand/context.md and AGENTS.md. Explain Markdown as a text document with headings in one sentence, then inspect the facts and review boundary. Open a fresh local project chat before prompt 02, or attach and explicitly read the files in Work.

TEACHING TIME
Allow 4 minutes within this single 60-minute session.

WHERE TO PASTE
Use the selected Work or local Codex project chat.

FILES BEFORE THIS PROMPT
An empty project and your interview answers. The prompt includes a fictional Copper Cup option.

COPYABLE PROMPT 01
Select only the text between the markers.

```text
BEGIN PROMPT 01
Interview me with questions to create two files for my AI marketing team: brand/context.md and AGENTS.md. Ask up to four concise questions, one at a time, and wait for my answers. Cover my brand, product, price and shipping, audience, campaign goal and channels, tone and visual direction, supported claims, requested outputs, available tools, and the actions that need my approval. Group related details in each question and offer an example answer when I need help. Use facts that I provide and identify gaps instead of inventing them.
For this class I can choose the Copper Cup demo. If I choose it, use these fictional facts and ask me to confirm or change them. Copper Cup Coffee sells a Discovery Box containing three 100 g bags, one light roast, one medium roast, and one dark roast, for USD 29 plus USD 5 shipping. The audience hypothesis is busy professionals brewing coffee at home. The CTA is Explore the Discovery Box. The voice is warm, specific, and restrained. The palette is cream #FAF4EA, espresso #2B2118, teal #087F8C, and copper #C76A42. The class goal is a reviewed ad concept and a small coordinated campaign package. Certifications, health benefits, sustainability claims, awards, testimonials, discounts, and performance promises require supporting sources.
After the interview, summarize confirmed facts and open questions, then create only the two named files. Put brand facts, audience hypotheses, voice, visuals, CTA, and a Current campaign section in brand/context.md. Put source-reading rules, role and skill routing, named draft output folders, missing-input handling, and human review boundaries in AGENTS.md. Project instructions operate within app permissions and higher-priority instructions. Show both saved paths and a short summary. Explain .md as a text document with headings in one sentence. Ask me to begin a fresh local Codex project chat before prompt 02 so the new instructions load. In Work, attach the files and explicitly request that they be read. Stop before creating skills, role cards, or campaign outputs.
Keep this classroom task inside the selected project. Prepare draft files only. Hold external sends, publication, scheduling, spending, deletion, and permission changes for a separate human decision. If file tools are unavailable, return downloadable files or full copyable text and name the missing file access. Report saved files separately from proposals.
END PROMPT 01
```

EXPECTED FILES OR RESULT
brand/context.md
AGENTS.md

CHECK BEFORE CONTINUING
Open the two files and confirm that your answers appear accurately. Find the Current campaign section and the human review boundary.

RECORDING CHECKLIST
Suggested edited clip length 90 seconds. Show the inputs, submit prompt 01, cut waiting time, open every named output, and demonstrate its source check. Show actual agent activity or the sequential fallback label. Hide unrelated account details and hold the checked result for five seconds. Record at 1920 by 1080.

INSERT RECORDING
Save the demonstration recording as recordings/01-demo.mp4. Insert the Google Drive video in the existing 16:9 frame. Remove the frame's instructional labels after insertion, preserving the quarter-width prompt panel and full prompt in the notes. The existing Onigiri setup recording remains on slide 14 and should be reviewed or replaced for the updated voice demonstration.

SOURCES
Fictional Copper Cup classroom example. Official file and agent guidance checked October 15, 2026.
https://learn.chatgpt.com/docs/agent-configuration/agents-md
https://learn.chatgpt.com/docs/build-skills
https://learn.chatgpt.com/docs/agent-configuration/subagents

## Slide 04 · Inspect the two interview outputs

TEACHING SCRIPT
The interview should create two files. Brand context contains the product, voice, visuals, and Current campaign section. AGENTS.md tells the project to read those sources, use relevant roles and skills, save draft outputs, and return decisions to the human. Check the supplied product, price, shipping, and CTA, then continue. A saved file path and accessible contents are the completion check.

TEACHING TIME
Allow 1 minute within this single 60-minute session.

SOURCES
Fictional Copper Cup classroom example. Official file and agent guidance checked October 15, 2026.
https://learn.chatgpt.com/docs/agent-configuration/agents-md
https://learn.chatgpt.com/docs/build-skills
https://learn.chatgpt.com/docs/agent-configuration/subagents

## Slide 05 · Skills, roles, and assignments

TEACHING SCRIPT
A skill describes how a repeatable task should proceed. An agent role describes who owns an assignment and its output. The user request starts the task and supplies its goal. We create one ad skill before asking the specialists to use it. A Markdown file without the required skill metadata can still provide reference instructions, but it should not be labeled a discovered skill.

TEACHING TIME
Allow 2 minutes within this single 60-minute session.

SOURCES
Fictional Copper Cup classroom example. Official file and agent guidance checked October 15, 2026.
https://learn.chatgpt.com/docs/agent-configuration/agents-md
https://learn.chatgpt.com/docs/build-skills
https://learn.chatgpt.com/docs/agent-configuration/subagents

## Slide 06 · Create the reusable ad skill

TEACHING SCRIPT
Prompt 02 reads the two foundation files and creates the ad skill. Open SKILL.md and point to name, description, process, and completion criteria. It reads the campaign assignment inside the context file. The class can finish with image prompts and a visual brief, while image generation remains subject to available tools and a separate decision.

TEACHING TIME
Allow 3 minutes within this single 60-minute session.

WHERE TO PASTE
Use the selected Work or local Codex project chat.

FILES BEFORE THIS PROMPT
AGENTS.md
brand/context.md

COPYABLE PROMPT 02
Select only the text between the markers.

```text
BEGIN PROMPT 02
Read AGENTS.md, brand/context.md, and the Current campaign section in brand/context.md. Create only .agents/skills/albert-copper-cup-ad-creative/SKILL.md. Include valid YAML frontmatter with name: albert-copper-cup-ad-creative and a description that triggers for Copper Cup ad copy, ad concepts, visual briefs, and image prompts.
The process should read the brand and brief, select an audience need, draft three copy options unless the assignment requests one, check each product claim against the source, propose visual direction and image prompts, and return a review checklist. Separate copy drafting from artwork generation. Keep image creation optional and subject to available tools and account permissions. Text drafts and image prompts are sufficient for this class. Name the saved campaign output directory and hold external actions for human review.
Explain the frontmatter name and description, then show the process headings and completion criteria. Saving this process does not start a specialist task. Show the saved file path and how to ask the next task to read this skill explicitly. Stop after creating and explaining the skill.
Keep this classroom task inside the selected project. Prepare draft files only. Hold external sends, publication, scheduling, spending, deletion, and permission changes for a separate human decision. If file tools are unavailable, provide the full named files as downloadable files or copyable text and explain how I can save them. Report actual saved files separately from proposed files.
END PROMPT 02
```

EXPECTED FILES OR RESULT
.agents/skills/albert-copper-cup-ad-creative/SKILL.md

CHECK BEFORE CONTINUING
Open SKILL.md, locate name and description between --- lines, and identify the source check and completion criteria.

RECORDING CHECKLIST
Suggested edited clip length 75 seconds. Show the inputs, submit prompt 02, cut waiting time, open every named output, and demonstrate its source check. Show actual agent activity or the sequential fallback label. Hide unrelated account details and hold the checked result for five seconds. Record at 1920 by 1080.

INSERT RECORDING
Save the demonstration recording as recordings/02-demo.mp4. Insert the Google Drive video in the existing 16:9 frame. Remove the frame's instructional labels after insertion, preserving the quarter-width prompt panel and full prompt in the notes. The existing Onigiri setup recording remains on slide 14 and should be reviewed or replaced for the updated voice demonstration.

SOURCES
Fictional Copper Cup classroom example. Official file and agent guidance checked October 15, 2026.
https://learn.chatgpt.com/docs/agent-configuration/agents-md
https://learn.chatgpt.com/docs/build-skills
https://learn.chatgpt.com/docs/agent-configuration/subagents

## Slide 07 · One lead and five specialists

TEACHING SCRIPT
The Marketing Team Lead coordinates the package and returns decisions to a human. The five specialists own strategy, copy, visual direction, a website preview, and metric findings. Saving their role files describes the team. The explicit assignments in later prompts start tasks. We inspect each output before the next dependent assignment.

TEACHING TIME
Allow 2 minutes within this single 60-minute session.

SOURCES
Fictional Copper Cup classroom example. Official file and agent guidance checked October 15, 2026.
https://learn.chatgpt.com/docs/agent-configuration/agents-md
https://learn.chatgpt.com/docs/build-skills
https://learn.chatgpt.com/docs/agent-configuration/subagents

## Slide 08 · Create the marketing team roles

TEACHING SCRIPT
Prompt 03 creates six Markdown role cards and, in local Codex, matching standalone TOML wrappers. Open one role card and identify its six responsibility fields. The local wrapper uses name, description, and developer_instructions while inheriting model settings and permissions. In Work, provide accessible role cards and explicitly delegate. Refresh or begin a fresh project chat if local definitions are absent.

TEACHING TIME
Allow 3 minutes within this single 60-minute session.

WHERE TO PASTE
Use the selected Work or local Codex project chat.

FILES BEFORE THIS PROMPT
AGENTS.md
brand/context.md
.agents/skills/albert-copper-cup-ad-creative/SKILL.md

COPYABLE PROMPT 03
Select only the text between the markers.

```text
BEGIN PROMPT 03
Read AGENTS.md, the brand context, its Current campaign section, and ad skill. Create six portable Markdown role cards under agents/ with these filenames and responsibilities.
marketing_lead.md coordinates the assignment, reads specialist outputs, resolves conflicts against sources, and returns a checked handoff and human decision. growth_strategist.md proposes an audience hypothesis, three ad angles, and a recommended test without promising results. content_creator.md turns the approved direction into headlines, body copy, and the supported CTA using the ad skill. creative_designer.md creates a visual brief, image prompts, and planned alt text using the approved copy and palette.
Add website_designer.md to own a local offer-page preview and source files. Add growth_analyst.md to own formula-based synthetic-data findings and limitations.
Give every role six fields: owns, inputs, may do, asks before, when unsure, and done when. State the output filenames for each role. Require AGENTS.md, brand/context.md, and the Current campaign section to be read. A role card describes a job; a later explicit assignment starts an agent task.
If this is local Codex with project-file access, also create matching .codex/agents/marketing_lead.toml, growth_strategist.toml, content_creator.toml, creative_designer.toml, website_designer.toml, and growth_analyst.toml. Each standalone file must contain name, description, and developer_instructions. Use the documented current schema and inherit model settings and permissions. Read the role card within developer_instructions. Explain the six role names and how to start a new chat or refresh the client if the saved definitions are absent. In Work Cloud, use the Markdown cards with explicit delegation instead of assuming that local TOML files register there. Keep this response to role creation and inspection, then wait for prompt 04.
Keep this classroom task inside the selected project. Prepare draft files only. Hold external sends, publication, scheduling, spending, deletion, and permission changes for a separate human decision. If file tools are unavailable, provide the full named files as downloadable files or copyable text and explain how I can save them. Report actual saved files separately from proposed files.
END PROMPT 03
```

EXPECTED FILES OR RESULT
agents/marketing_lead.md
agents/growth_strategist.md
agents/content_creator.md
agents/creative_designer.md
agents/website_designer.md
agents/growth_analyst.md
.codex/agents/marketing_lead.toml
.codex/agents/growth_strategist.toml
.codex/agents/content_creator.toml
.codex/agents/creative_designer.toml
.codex/agents/website_designer.toml
.codex/agents/growth_analyst.toml

CHECK BEFORE CONTINUING
Inspect one role card and its local TOML wrapper. Explain each specialist output before starting an assignment.

RECORDING CHECKLIST
Suggested edited clip length 90 seconds. Show the inputs, submit prompt 03, cut waiting time, open every named output, and demonstrate its source check. Show actual agent activity or the sequential fallback label. Hide unrelated account details and hold the checked result for five seconds. Record at 1920 by 1080.

INSERT RECORDING
Save the demonstration recording as recordings/03-demo.mp4. Insert the Google Drive video in the existing 16:9 frame. Remove the frame's instructional labels after insertion, preserving the quarter-width prompt panel and full prompt in the notes. The existing Onigiri setup recording remains on slide 14 and should be reviewed or replaced for the updated voice demonstration.

SOURCES
Fictional Copper Cup classroom example. Official file and agent guidance checked October 15, 2026.
https://learn.chatgpt.com/docs/agent-configuration/agents-md
https://learn.chatgpt.com/docs/build-skills
https://learn.chatgpt.com/docs/agent-configuration/subagents

## Slide 09 · The strategist chooses an ad direction

TEACHING SCRIPT
Prompt 04 explicitly starts the Growth Strategist assignment. Show its activity or task reference if available, then open strategy.md. Compare the three proposed angles and selected recommendation. The supplied brand facts support the offer, while the audience explanation remains a testable hypothesis. If this account cannot delegate, label the result a sequential role-based draft so the class can distinguish that path from a separate agent run.

TEACHING TIME
Allow 3 minutes within this single 60-minute session.

WHERE TO PASTE
Use the selected Work or local Codex project chat.

FILES BEFORE THIS PROMPT
AGENTS.md
brand/context.md
agents/growth_strategist.md

COPYABLE PROMPT 04
Select only the text between the markers.

```text
BEGIN PROMPT 04
Read AGENTS.md and agents/growth_strategist.md. Explicitly start the Growth Strategist assignment using brand/context.md and the Current campaign section in brand/context.md. Propose three audience-specific ad angles, recommend one, and describe one testable hypothesis. Use only the supplied fictional facts and label audience reasoning as a hypothesis. Save campaigns/discovery-box/run-01/strategy.md with the source paths, angle comparison, chosen direction, and next handoff to the Content Creator. Report the supported offer and the questions a human should review before continuing.
Use a supported subagent workflow for this assignment. In local Codex use the named custom agent if available, or pass the complete role card to a supported worker. In Work explicitly delegate with the role instructions and accessible project files. If subagents are unavailable, label the result a sequential role-based draft and explain that fallback. Return the visible task reference when available, actual execution mode, output path, source check, and missing inputs. A saved role card alone is not evidence that a separate agent ran.
Keep this classroom task inside the selected project. Prepare draft files only. Hold external sends, publication, scheduling, spending, deletion, and permission changes for a separate human decision. If file tools are unavailable, provide the full named files as downloadable files or copyable text and explain how I can save them. Report actual saved files separately from proposed files.
END PROMPT 04
```

EXPECTED FILES OR RESULT
campaigns/discovery-box/run-01/strategy.md

CHECK BEFORE CONTINUING
Inspect the task activity or fallback label, then find the chosen angle, supporting facts, and next owner.

RECORDING CHECKLIST
Suggested edited clip length 75 seconds. Show the inputs, submit prompt 04, cut waiting time, open every named output, and demonstrate its source check. Show actual agent activity or the sequential fallback label. Hide unrelated account details and hold the checked result for five seconds. Record at 1920 by 1080.

INSERT RECORDING
Save the demonstration recording as recordings/04-demo.mp4. Insert the Google Drive video in the existing 16:9 frame. Remove the frame's instructional labels after insertion, preserving the quarter-width prompt panel and full prompt in the notes. The existing Onigiri setup recording remains on slide 14 and should be reviewed or replaced for the updated voice demonstration.

SOURCES
Fictional Copper Cup classroom example. Official file and agent guidance checked October 15, 2026.
https://learn.chatgpt.com/docs/agent-configuration/agents-md
https://learn.chatgpt.com/docs/build-skills
https://learn.chatgpt.com/docs/agent-configuration/subagents

## Slide 10 · Copy and design use a visible handoff

TEACHING SCRIPT
Prompt 05 first assigns the Content Creator and waits for ad-copy.md. It then assigns the Creative Designer with that saved copy and the chosen strategy. Show the dependency and the two task references or sequential fallback labels. The design result contains a visual brief, image prompt, and planned alt text. Inspect price, shipping, product count, CTA, and the distinction between a proposed image and generated artwork.

TEACHING TIME
Allow 4 minutes within this single 60-minute session.

WHERE TO PASTE
Use the selected Work or local Codex project chat.

FILES BEFORE THIS PROMPT
AGENTS.md
brand/context.md
.agents/skills/albert-copper-cup-ad-creative/SKILL.md
agents/content_creator.md
agents/creative_designer.md
campaigns/discovery-box/run-01/strategy.md

COPYABLE PROMPT 05
Select only the text between the markers.

```text
BEGIN PROMPT 05
Read AGENTS.md, brand/context.md including Current campaign, the saved campaigns/discovery-box/run-01/strategy.md, and the ad skill. Explicitly assign the Content Creator using agents/content_creator.md to draft three Instagram copy options. Each option needs a headline, body, CTA, audience rationale, and source-backed product claims. Save campaigns/discovery-box/run-01/ad-copy.md and choose one option for design.
Wait for the copy file, then explicitly assign the Creative Designer using agents/creative_designer.md. Read that copy, the chosen strategy, context, and skill. Save visual-brief.md and image-prompts.md in the same run-01 folder. Include square composition, palette, readable text placement, accurate product count, and planned alt text. Keep image generation as a separate tool decision. Label planned alt text pending image inspection.
Check three 100 g bags, USD 29, USD 5 shipping, and Explore the Discovery Box against the context. Show the copy-to-design handoff and both task references or sequential fallback labels. Preserve the supported offer if the interview changed other campaign details.
Use explicit subagent assignments when supported. Use the named local Codex role or pass its complete Markdown instructions to an available worker. In Work, supply accessible files and explicitly delegate. Return actual task activity or references and output paths. If delegation is unavailable, label the result a sequential role-based draft. A role definition alone is not an agent execution receipt.
Keep this classroom task inside the selected project. Prepare draft files only. Hold external sends, publication, scheduling, spending, deletion, and permission changes for a separate human decision. If file tools are unavailable, return downloadable files or full copyable text and name the missing file access. Report saved files separately from proposals.
END PROMPT 05
```

EXPECTED FILES OR RESULT
campaigns/discovery-box/run-01/ad-copy.md
campaigns/discovery-box/run-01/visual-brief.md
campaigns/discovery-box/run-01/image-prompts.md

CHECK BEFORE CONTINUING
Inspect the copy first, then the design file that consumed it. Trace a product claim and distinguish planned artwork from a generated image.

RECORDING CHECKLIST
Suggested edited clip length 90 seconds. Show the inputs, submit prompt 05, cut waiting time, open every named output, and demonstrate its source check. Show actual agent activity or the sequential fallback label. Hide unrelated account details and hold the checked result for five seconds. Record at 1920 by 1080.

INSERT RECORDING
Save the demonstration recording as recordings/05-demo.mp4. Insert the Google Drive video in the existing 16:9 frame. Remove the frame's instructional labels after insertion, preserving the quarter-width prompt panel and full prompt in the notes. The existing Onigiri setup recording remains on slide 14 and should be reviewed or replaced for the updated voice demonstration.

SOURCES
Fictional Copper Cup classroom example. Official file and agent guidance checked October 15, 2026.
https://learn.chatgpt.com/docs/agent-configuration/agents-md
https://learn.chatgpt.com/docs/build-skills
https://learn.chatgpt.com/docs/agent-configuration/subagents

## Slide 11 · A handoff includes sources and an output

TEACHING SCRIPT
At each handoff, ask for the source paths, actual output path, and next owner. Task activity proves that an assignment started, while a checked artifact supports completion. An answer saying an agent is ready provides neither the finished file nor its review. Resolve missing inputs before the next role consumes them.

TEACHING TIME
Allow 1 minute within this single 60-minute session.

SOURCES
Fictional Copper Cup classroom example. Official file and agent guidance checked October 15, 2026.
https://learn.chatgpt.com/docs/agent-configuration/agents-md
https://learn.chatgpt.com/docs/build-skills
https://learn.chatgpt.com/docs/agent-configuration/subagents

## Slide 12 · One campaign goal coordinates the team

TEACHING SCRIPT
Act as Marketing Team Lead in the main conversation so the host can coordinate specialist tasks without depending on nested delegation settings. The strategist confirms direction first. Other specialists then draft separate social, visual, website, and analysis files from the shared sources. Queue tasks within the client limit and wait for their outputs. Show the static offer-page preview and one metric calculation. The lead checks the combined package, assigns a revision if needed, and returns a handoff. The class data is synthetic, and the two objectives prevent a causal performance comparison.

TEACHING TIME
Allow 7 minutes within this single 60-minute session.

WHERE TO PASTE
Use the selected Work or local Codex project chat.

FILES BEFORE THIS PROMPT
AGENTS.md
brand/context.md
.agents/skills/albert-copper-cup-ad-creative/SKILL.md
agents/marketing_lead.md
agents/growth_strategist.md
agents/content_creator.md
agents/creative_designer.md
agents/website_designer.md
agents/growth_analyst.md
campaigns/discovery-box/run-01/strategy.md
campaigns/discovery-box/run-01/ad-copy.md
campaigns/discovery-box/run-01/visual-brief.md
campaigns/discovery-box/run-01/image-prompts.md

COPYABLE PROMPT 06
Select only the text between the markers.

```text
BEGIN PROMPT 06
Act as the Marketing Team Lead in this main project conversation. Read AGENTS.md, agents/marketing_lead.md, brand/context.md including Current campaign, all five specialist role cards, the ad skill, and the saved run-01 package. Explicitly coordinate a small campaign package under campaigns/discovery-box/coordinated-01/. Create independent output files so agents avoid editing one shared file.
First ask the Growth Strategist to confirm a campaign direction and acceptance criteria from the existing strategy. After that result, delegate these independent assignments using the confirmed direction and existing reviewed inputs. The Content Creator prepares three draft social posts. The Creative Designer prepares a visual brief and image prompt for the campaign. The Website Designer creates an editable static offer-page.html with a local preview and supported offer copy, with payment and lead collection absent. The Growth Analyst reviews the synthetic data below, showing CTR, lead conversion, cost per lead, and cost per order with denominators and objective caveats. Respect the client's concurrency limits and queue tasks when needed. The main conversation waits for the specialist outputs and merges the result.
Save this supplied fictional data as data/classroom-campaigns.csv before the analyst reads it:
campaign,objective,spend_usd,impressions,clicks,landing_visits,leads,orders
Brew guide,Lead acquisition,400,40000,1000,720,144,18
Discovery Box,Purchase,800,50000,1250,900,54,48
Use CTR = clicks / impressions * 100; lead conversion = leads / landing_visits * 100; CPL = spend_usd / leads; cost per order = spend_usd / orders. Leads and orders measure different outcomes. Different objectives and the absence of randomized assignment prevent a causal comparison. Revenue and profit are unspecified.
Review the actual saved files against the brand, Current campaign section, price, shipping, CTA, source evidence, and channel fit. Assign a specific revision to its owning specialist if needed, then recheck. Save review.md and handoff.md with actual files, task references or fallback labels, checked calculations, gaps, and the next human decision. Hold image-generation charges and external actions for separate decisions.
Use explicit subagent assignments when supported. Use the named local Codex role or pass its complete Markdown instructions to an available worker. In Work, supply accessible files and explicitly delegate. Return actual task activity or references and output paths. If delegation is unavailable, label the result a sequential role-based draft. A role definition alone is not an agent execution receipt.
Keep this classroom task inside the selected project. Prepare draft files only. Hold external sends, publication, scheduling, spending, deletion, and permission changes for a separate human decision. If file tools are unavailable, return downloadable files or full copyable text and name the missing file access. Report saved files separately from proposals.
END PROMPT 06
```

EXPECTED FILES OR RESULT
data/classroom-campaigns.csv
campaigns/discovery-box/coordinated-01/strategy.md
campaigns/discovery-box/coordinated-01/social-posts.md
campaigns/discovery-box/coordinated-01/visual-brief.md
campaigns/discovery-box/coordinated-01/image-prompts.md
campaigns/discovery-box/coordinated-01/offer-page.html
campaigns/discovery-box/coordinated-01/findings.md
campaigns/discovery-box/coordinated-01/review.md
campaigns/discovery-box/coordinated-01/handoff.md

CHECK BEFORE CONTINUING
Inspect the separate agent assignments, static page preview, one calculation, and the merged review. A running status remains separate from a checked result.

RECORDING CHECKLIST
Suggested edited clip length 120 seconds. Show the inputs, submit prompt 06, cut waiting time, open every named output, and demonstrate its source check. Show actual agent activity or the sequential fallback label. Hide unrelated account details and hold the checked result for five seconds. Record at 1920 by 1080.

INSERT RECORDING
Save the demonstration recording as recordings/06-demo.mp4. Insert the Google Drive video in the existing 16:9 frame. Remove the frame's instructional labels after insertion, preserving the quarter-width prompt panel and full prompt in the notes. The existing Onigiri setup recording remains on slide 14 and should be reviewed or replaced for the updated voice demonstration.

SOURCES
Fictional Copper Cup classroom example. Official file and agent guidance checked October 15, 2026.
https://learn.chatgpt.com/docs/agent-configuration/agents-md
https://learn.chatgpt.com/docs/build-skills
https://learn.chatgpt.com/docs/agent-configuration/subagents

## Slide 13 · The review checks outputs and decisions

TEACHING SCRIPT
Open the coordinated campaign files and review.md. Compare a source-backed product claim with the static page copy, then trace a metric calculation to its stated denominator. Ask which decision remains with the human. The prepared examples support teaching if a live task stalls, with their prepared status visible.

TEACHING TIME
Allow 2 minutes within this single 60-minute session.

SOURCES
Fictional Copper Cup classroom example. Official file and agent guidance checked October 15, 2026.
https://learn.chatgpt.com/docs/agent-configuration/agents-md
https://learn.chatgpt.com/docs/build-skills
https://learn.chatgpt.com/docs/agent-configuration/subagents

## Slide 14 · Onigiri coordinates through voice and chat

TEACHING SCRIPT
The existing instructor capture shows Onigiri project setup and remains in this recording frame. A new capture should include the complete voice-to-task handoff. Confirm the prepared project and actual computer or app access, then give the assignment by voice or text. End with the written task reference, checked output, and pending decision. Closing the call can leave delegated tasks running, so inspect task activity separately. Use a labeled prepared example if the capability is unavailable.

TEACHING TIME
Allow 4 minutes within this single 60-minute session.

WHERE TO PASTE
Use the prepared Dot conversation or read the request during a call.

FILES BEFORE THIS PROMPT
AGENTS.md
brand/context.md
campaigns/discovery-box/coordinated-01/handoff.md

COPYABLE PROMPT 07
Select only the text between the markers.

```text
BEGIN PROMPT 07
Use Onigiri, my Personalized ChatGPT Dot, to coordinate the prepared Copper Cup project. Read AGENTS.md, brand/context.md, and campaigns/discovery-box/coordinated-01/handoff.md. Confirm the project path and available computer or app connection. Start a separate local Codex task or an available Work task with the attached sources to prepare the next draft revision. If I give the request through voice, leave a written task reference and result in this conversation.
Return the task link, current status, saved output path, source checks, and pending human decision. After completion, inspect the file against the context before reporting a checked result. Explain that ending a call can leave assigned tasks running, and identify the available task-activity controls. If Dot, voice, task creation, or computer access is unavailable, explain the gap and return a clearly labeled text draft for the instructor to demonstrate.
Keep this classroom task inside the selected project. Prepare draft files only. Hold external sends, publication, scheduling, spending, deletion, and permission changes for a separate human decision. If file tools are unavailable, return downloadable files or full copyable text and name the missing file access. Report saved files separately from proposals.
END PROMPT 07
```

EXPECTED FILES OR RESULT
A written task reference, status, and checked revision handoff

CHECK BEFORE CONTINUING
Open the written result after the call. Verify its sources, output path, and pending decision.

RECORDING CHECKLIST
Suggested edited clip length 90 seconds. Show the inputs, submit prompt 07, cut waiting time, open every named output, and demonstrate its source check. Show actual agent activity or the sequential fallback label. Hide unrelated account details and hold the checked result for five seconds. Record at 1920 by 1080.

INSERT RECORDING
Save the demonstration recording as recordings/07-demo.mp4. Insert the Google Drive video in the existing 16:9 frame. Remove the frame's instructional labels after insertion, preserving the quarter-width prompt panel and full prompt in the notes. The existing Onigiri setup recording remains on slide 14 and should be reviewed or replaced for the updated voice demonstration.

SOURCES
Fictional Copper Cup classroom example. Official file and agent guidance checked October 15, 2026.
https://learn.chatgpt.com/docs/agent-configuration/agents-md
https://learn.chatgpt.com/docs/build-skills
https://learn.chatgpt.com/docs/agent-configuration/subagents

Connected-tool guidance checked October 15, 2026.
https://learn.chatgpt.com/docs/dots
https://learn.chatgpt.com/docs/dots/controls

## Slide 15 · A private Page keeps the campaign together

TEACHING SCRIPT
Prompt 08 packages attached source files, reviewed outputs, and the full core prompts into a private campaign library. Show the Page link, source references, draft labels, and owner-only access before any sharing. If Pages is unavailable, show the structured document fallback. The library supports the campaign handoff within this lesson and leaves public launch as a separate decision.

TEACHING TIME
Allow 3 minutes within this single 60-minute session.

WHERE TO PASTE
Use the connected Work or Dot conversation with the named attachments.

FILES BEFORE THIS PROMPT
Attached brand/context.md
Attached AGENTS.md
Attached full prompts 01–10
Attached reviewed coordinated-01 outputs and source links

COPYABLE PROMPT 08
Select only the text between the markers.

```text
BEGIN PROMPT 08
Use the attached brand context including Current campaign, full core prompts 01–10, reviewed outputs, and source links to create a private Page titled Copper Cup Campaign Kit in my Personal Space. Preserve every supplied prompt verbatim with its required inputs and review check. Keep access owner-only and return the Page link and access summary in this conversation. If Pages is unavailable, return a structured document for me to save. Hold sharing and public Site creation for separate decisions.
Keep this classroom task inside the selected project. Prepare draft files only. Hold external sends, publication, scheduling, spending, deletion, and permission changes for a separate human decision. If file tools are unavailable, provide the full named files as downloadable files or copyable text and explain how I can save them. Report actual saved files separately from proposed files.
END PROMPT 08
```

EXPECTED FILES OR RESULT
A private campaign Page or a structured document fallback

CHECK BEFORE CONTINUING
Inspect the Page or fallback, source links, full prompts, draft labels, and owner-only access.

RECORDING CHECKLIST
Suggested edited clip length 60 seconds. Show the inputs, submit prompt 08, cut waiting time, open every named output, and demonstrate its source check. Show actual agent activity or the sequential fallback label. Hide unrelated account details and hold the checked result for five seconds. Record at 1920 by 1080.

INSERT RECORDING
Save the demonstration recording as recordings/08-demo.mp4. Insert the Google Drive video in the existing 16:9 frame. Remove the frame's instructional labels after insertion, preserving the quarter-width prompt panel and full prompt in the notes. The existing Onigiri setup recording remains on slide 14 and should be reviewed or replaced for the updated voice demonstration.

SOURCES
Fictional Copper Cup classroom example. Official file and agent guidance checked October 15, 2026.
https://learn.chatgpt.com/docs/agent-configuration/agents-md
https://learn.chatgpt.com/docs/build-skills
https://learn.chatgpt.com/docs/agent-configuration/subagents

Connected-tool guidance checked October 15, 2026.
https://learn.chatgpt.com/docs/dots
https://learn.chatgpt.com/docs/dots/controls

## Slide 16 · A brief leads with the next decision

TEACHING SCRIPT
Prompt 09 produces one marketing brief and proposes two bounded routines. The brief leads with the next decision and includes sources, missing inputs, and status. Review the proposed time zone, dates, destination, alert conditions, usage, and pause controls. Keep schedules disabled during the class. If the account cannot schedule, show the written proposal and its pending activation decision.

TEACHING TIME
Allow 3 minutes within this single 60-minute session.

WHERE TO PASTE
Use the connected Work or Dot conversation with the named attachments.

FILES BEFORE THIS PROMPT
Attached reviewed coordinated-01 outputs and source links

COPYABLE PROMPT 09
Select only the text between the markers.

```text
BEGIN PROMPT 09
Read the attached reviewed Copper Cup outputs and sources. Draft a one-time brief led by the next human decision, current status, missing inputs, and source references. Then propose a weekday 09:00 America/Los_Angeles brief and hourly checks during 09:00–17:00 for one chosen teaching week. Request the actual start and end dates and destination. Limit alerts to a changed offer, deadline risk, missing input, or decision awaiting review. Explain account usage and controls for pausing future schedules and inspecting active delegated tasks. Keep both schedules disabled and wait for a separate activation decision.
Keep this classroom task inside the selected project. Prepare draft files only. Hold external sends, publication, scheduling, spending, deletion, and permission changes for a separate human decision. If file tools are unavailable, provide the full named files as downloadable files or copyable text and explain how I can save them. Report actual saved files separately from proposed files.
END PROMPT 09
```

EXPECTED FILES OR RESULT
One-time marketing brief and two disabled schedule proposals

CHECK BEFORE CONTINUING
Identify the next human decision, source limits, time zone, end date, destination, and disabled status.

RECORDING CHECKLIST
Suggested edited clip length 75 seconds. Show the inputs, submit prompt 09, cut waiting time, open every named output, and demonstrate its source check. Show actual agent activity or the sequential fallback label. Hide unrelated account details and hold the checked result for five seconds. Record at 1920 by 1080.

INSERT RECORDING
Save the demonstration recording as recordings/09-demo.mp4. Insert the Google Drive video in the existing 16:9 frame. Remove the frame's instructional labels after insertion, preserving the quarter-width prompt panel and full prompt in the notes. The existing Onigiri setup recording remains on slide 14 and should be reviewed or replaced for the updated voice demonstration.

SOURCES
Fictional Copper Cup classroom example. Official file and agent guidance checked October 15, 2026.
https://learn.chatgpt.com/docs/agent-configuration/agents-md
https://learn.chatgpt.com/docs/build-skills
https://learn.chatgpt.com/docs/agent-configuration/subagents

Connected-tool guidance checked October 15, 2026.
https://learn.chatgpt.com/docs/dots
https://learn.chatgpt.com/docs/dots/controls

## Slide 17 · Your ten-minute guided exercise

TEACHING SCRIPT
Prompt 10 changes the audience and message while preserving the supported offer. Spend two minutes checking the assignment, five creating one revised concept, and three reviewing the result. The saved exercise assignment and output remain separate from the earlier campaign.

TEACHING TIME
Allow 1 minute within this single 60-minute session.

SOURCES
Fictional Copper Cup classroom example. Official file and agent guidance checked October 15, 2026.
https://learn.chatgpt.com/docs/agent-configuration/agents-md
https://learn.chatgpt.com/docs/build-skills
https://learn.chatgpt.com/docs/agent-configuration/subagents

## Slide 18 · Adapt and review your campaign concept

TEACHING SCRIPT
Ask learners to paste prompt 10 into their prepared project. They should preserve the original context and runs while saving a changed audience assignment and one reviewed concept. Circulate and ask them to identify a source-backed claim and the actual task activity or fallback label. If generation stalls, use the prepared exercise answer for the review portion. Invite one audience change and one revision decision.

TEACHING TIME
Allow 10 minutes within this single 60-minute session.

WHERE TO PASTE
Use the selected Work or local Codex project chat.

FILES BEFORE THIS PROMPT
AGENTS.md
brand/context.md
.agents/skills/albert-copper-cup-ad-creative/SKILL.md
agents/marketing_lead.md
agents/growth_strategist.md
agents/content_creator.md
agents/creative_designer.md
agents/website_designer.md
agents/growth_analyst.md
campaigns/discovery-box/run-01/strategy.md
campaigns/discovery-box/run-01/ad-copy.md
campaigns/discovery-box/coordinated-01/handoff.md

COPYABLE PROMPT 10
Select only the text between the markers.

```text
BEGIN PROMPT 10
Read AGENTS.md, brand/context.md including Current campaign, the ad skill, all six role cards, the reviewed run-01 files, and coordinated-01/handoff.md. Complete a ten-minute exercise for people setting up their first home office. Preserve the supported product, price, shipping, and CTA. For the Copper Cup demo those are three 100 g bags, USD 29, USD 5 shipping, and Explore the Discovery Box.
Act as Marketing Team Lead in the main conversation. Save the changed audience assignment as campaigns/discovery-box/exercise-01/assignment.md while preserving the original context and earlier runs. Explicitly assign a short audience rationale to the Growth Strategist, then one revised copy concept and visual direction to the Content Creator and Creative Designer. Return the strategy, headline, body, CTA, visual direction, image prompt, and planned alt text in one concept-and-review.md file in that exercise folder. Include a before-and-after audience comparison, a source-check table, actual task references or sequential fallback labels, and one human revision decision. Keep image generation and external actions pending separate decisions.
Use explicit subagent assignments when supported. Use the named local Codex role or pass its complete Markdown instructions to an available worker. In Work, supply accessible files and explicitly delegate. Return actual task activity or references and output paths. If delegation is unavailable, label the result a sequential role-based draft. A role definition alone is not an agent execution receipt.
Keep this classroom task inside the selected project. Prepare draft files only. Hold external sends, publication, scheduling, spending, deletion, and permission changes for a separate human decision. If file tools are unavailable, return downloadable files or full copyable text and name the missing file access. Report saved files separately from proposals.
END PROMPT 10
```

EXPECTED FILES OR RESULT
campaigns/discovery-box/exercise-01/assignment.md
campaigns/discovery-box/exercise-01/concept-and-review.md

CHECK BEFORE CONTINUING
Compare audiences, trace one claim, preserve the supported offer, and choose a specific revision.

RECORDING CHECKLIST
The exercise runs for ten minutes; a prepared 60-second example can support review. Show the inputs, submit prompt 10, cut waiting time, open every named output, and demonstrate its source check. Show actual agent activity or the sequential fallback label. Hide unrelated account details and hold the checked result for five seconds. Record at 1920 by 1080.

INSERT RECORDING
Save the demonstration recording as recordings/10-demo.mp4. Insert the Google Drive video in the existing 16:9 frame. Remove the frame's instructional labels after insertion, preserving the quarter-width prompt panel and full prompt in the notes. The existing Onigiri setup recording remains on slide 14 and should be reviewed or replaced for the updated voice demonstration.

SOURCES
Fictional Copper Cup classroom example. Official file and agent guidance checked October 15, 2026.
https://learn.chatgpt.com/docs/agent-configuration/agents-md
https://learn.chatgpt.com/docs/build-skills
https://learn.chatgpt.com/docs/agent-configuration/subagents

## Slide 19 · A reviewed result includes evidence

TEACHING SCRIPT
Invite one learner to explain the audience change and read a supported claim. Check the product quantity, price, shipping, and CTA against the context file. Review the task activity or sequential fallback label separately from the artifact contents. Ask for one useful revision to copy or visual direction. If a recurring defect appears, repair the skill or role instructions and retest a varied case.

TEACHING TIME
Allow 2 minutes within this single 60-minute session.

SOURCES
Fictional Copper Cup classroom example. Official file and agent guidance checked October 15, 2026.
https://learn.chatgpt.com/docs/agent-configuration/agents-md
https://learn.chatgpt.com/docs/build-skills
https://learn.chatgpt.com/docs/agent-configuration/subagents

## Slide 20 · Open Q&A and next decisions

TEACHING SCRIPT
Invite questions about the interview, files, skills, role assignments, tool access, and coordinated review. Ask learners to name one file, one agent assignment, and one source check they can explain. Point them to the full workbook and prepared reference files for independent use. This is the complete teaching session, with all ten prompts already introduced. Human review still governs sends, schedules, publication, and spending.

TEACHING TIME
Allow 3 minutes within this single 60-minute session.

SOURCES
Fictional Copper Cup classroom example. Official file and agent guidance checked October 15, 2026.
https://learn.chatgpt.com/docs/agent-configuration/agents-md
https://learn.chatgpt.com/docs/build-skills
https://learn.chatgpt.com/docs/agent-configuration/subagents

## Slide 21 · Files created during this session

TEACHING SCRIPT
The interview creates brand/context.md and AGENTS.md. Later prompts add the skill, role cards, local wrappers when applicable, and named campaign outputs. This file map records completion criteria, while the class starts from an empty project. The prepared examples remain comparison material.

TEACHING TIME
Reference slide outside the timed teaching sequence.

SOURCES
Fictional Copper Cup classroom example. Official file and agent guidance checked October 15, 2026.
https://learn.chatgpt.com/docs/agent-configuration/agents-md
https://learn.chatgpt.com/docs/build-skills
https://learn.chatgpt.com/docs/agent-configuration/subagents

## Slide 22 · A role definition and an active assignment

TEACHING SCRIPT
Inspect the Growth Strategist card before starting its task. Its responsibility remains stable across assignments. A new assignment supplies the campaign goal and requested output. Saving the Markdown card describes a role, and a local TOML wrapper makes that role available to supported Codex clients. The task becomes active only after an explicit delegation request. Confirm activity and the returned output when you run the next prompt.

TEACHING TIME
Reference slide outside the timed teaching sequence.

SOURCES
Fictional Copper Cup classroom example. Official file and agent guidance checked October 15, 2026.
https://learn.chatgpt.com/docs/agent-configuration/agents-md
https://learn.chatgpt.com/docs/build-skills
https://learn.chatgpt.com/docs/agent-configuration/subagents

## Slide 23 · Accounts and tool access

TEACHING SCRIPT
Use local Codex with file access or a fresh Work workspace with accessible files. Dot and voice need the appropriate connection and capability. Pages and recurring tasks depend on account availability and permissions. Keep labeled prepared captures ready for tools that are unavailable. The screenshots show the instructor app menus, whose labels can vary as products change.

TEACHING TIME
Reference slide outside the timed teaching sequence.

SOURCES
Fictional Copper Cup classroom example. Official file and agent guidance checked October 15, 2026.
https://learn.chatgpt.com/docs/agent-configuration/agents-md
https://learn.chatgpt.com/docs/build-skills
https://learn.chatgpt.com/docs/agent-configuration/subagents

## Slide 24 · Sources and course adaptation

TEACHING SCRIPT
The class adapts marketing team examples from Grace Leung and Dot coordination concepts from Riley Brown. The instructor-supplied Leland template defines the design. The October 15 revision replaces detailed file walkthroughs with one interview that creates the context and project instructions, keeping medium and advanced demonstrations in a single 60-minute class. Official AGENTS.md, skill, and subagent guidance was checked October 15, 2026.

TEACHING TIME
Reference slide outside the timed teaching sequence.

SOURCES
Fictional Copper Cup classroom example. Official file and agent guidance checked October 15, 2026.
https://learn.chatgpt.com/docs/agent-configuration/agents-md
https://learn.chatgpt.com/docs/build-skills
https://learn.chatgpt.com/docs/agent-configuration/subagents
https://www.youtube.com/watch?v=BzS93V2zFTg
https://www.youtube.com/watch?v=WXhOxfPECnM
