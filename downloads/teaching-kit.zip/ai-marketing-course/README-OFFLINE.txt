Build Your AI Marketing Team with Agents

Open docs/learner-workbook.md or downloads/learner-workbook.pdf to follow the lesson. The updated workbook contains 16 numbered prompts and four optional follow-ups. The presentation PDF contains 35 slides, with slides 1 through 29 filling the 60-minute class.

Open course-files as the project folder in your available ChatGPT Work or Codex environment. Keep the hidden .agents and .codex folders intact. Open docs/instructor-notes.md for the speaking scripts, complete prompts, and recording checklists. Open recordings/README.md for recording filenames and the updated slide numbers.

The classroom campaign remains fictional and draft-only. Follow docs/agent-operating-guide.md to define roles, scope permissions, rehearse varied cases, and review each autonomy expansion.

Editable Google Slides
https://docs.google.com/presentation/d/1EY7U2ZDfHXPUsubG0SyrNJdkPEbLEOhQGgygsC7SWC0/edit

Course repository
https://github.com/albert-rowland/AI-in-Marketing
